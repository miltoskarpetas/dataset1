# 🐾 Animals Image Dataset

Το **Animals Image Dataset** περιέχει εικόνες γάτας και σκύλου για χρήση σε εκπαιδευτικά ή ερευνητικά έργα Τεχνητής Νοημοσύνης.

## 📁 Δομή
- `data/train/` – Εικόνες για εκπαίδευση (cats, dogs)
- `data/test/` – Εικόνες για έλεγχο

## ⚙️ Μορφή δεδομένων
- Όλες οι εικόνες είναι JPEG 256×256
- Οι ετικέτες αντιστοιχούν σε ονόματα φακέλων (`cats`, `dogs`)

## 🧾 Μεταδεδομένα
Περιλαμβάνονται στο αρχείο `metadata.json`.

## 📜 Άδεια
Το dataset διατίθεται υπό άδεια **CC-BY 4.0**.

## 💡 Παράδειγμα χρήσης (Python)
```python
from tensorflow.keras.preprocessing.image import ImageDataGenerator

datagen = ImageDataGenerator(rescale=1./255)
train_data = datagen.flow_from_directory('data/train', target_size=(256,256), class_mode='binary')
```
